import axios from "axios";
import React, { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from 'react-helmet';

const BootstrapModal = ({ isOpen, onClose }) => {
    const [selectedHotel, setSelectedHotel] = useState(null);
    const [toggle, settoggle] = useState(true);
    const [errors, setErrors] = useState({});
    const [formData, setFormData] = useState({
        customer_name: '',
        contact_number: '',
        address: ''
    });
    const[hasid,sethasId] = useState(sessionStorage.getItem('orderid')!=null);

    const navigate = useNavigate();
    const hasPaymentHandlerRun = useRef(false);

    if (!isOpen) return null;

    const handleChange = (e) => {
        const { id, value, type, files } = e.target;

        if (type === 'file') {
            setFormData({ ...formData, [id]: files[0] });
        } else {
            setFormData({ ...formData, [id]: value });
        }
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        const validationErrors = {};
        if (!formData.customer_name.trim()) {
            validationErrors.name = 'Name is required';
        }
        if (!formData.contact_number.trim()) {
            validationErrors.contact = 'Contact Number is required';
        } else if (!/^\d{10}$/.test(formData.contact_number.trim())) {
            validationErrors.contact = 'Contact Number must be 10 digits';
        }

        if (!formData.address) {
            validationErrors.address = 'Address is required';
        }

        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }

        try {
            if (!hasPaymentHandlerRun.current) {
                const order = await paymenthandler();
                hasPaymentHandlerRun.current = true;
                onClose();
            }
        } catch (error) {
            console.error('Error in payment process:', error);
        }
    };

    const paymenthandler = async () => {
        const amount = 21 * 100;
        const currency = 'INR';
        const receiptId = "446545";

        try {
            const response = await axios.post('http://127.0.0.1:8000/api/create_order/', {
                amount: amount,
                currency: currency,
                receipt: receiptId
            }, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const order = response.data;
            const options = {
                key: "rzp_test_il5eIvVmXeSgBb",
                amount: amount,
                currency: currency,
                name: "HTH Hotel",
                description: "Test Transaction",
                image: "https://img.freepik.com/premium-vector/hotel-logo-simple-illustration_434503-736.jpg?w=2000",
                order_id: order.id,
                handler: async function (response) {
                    try {
                        const body = { ...response };
                        sessionStorage.setItem('orderid', body.razorpay_order_id);
                        const obj = {...formData,razorpay_order_id:body.razorpay_order_id,razorpay_payment_id:body.razorpay_payment_id}
                        await axios.post('http://127.0.0.1:8000/api/customers/', obj);

                    } catch (error) {
                        console.error('Error during order validation:', error);
                    }
                },
                prefill: {
                    name: "HTH",
                    email: "a@gmail.com",
                    contact: "9691113785"
                },
                notes: {
                    address: "Razorpay Corporate Office"
                },
                theme: {
                    color: "#3309cc"
                }
            };

            const rzp1 = new window.Razorpay(options);
            rzp1.on("payment.failed", function (response) {
                alert("Payment Failed");
            });
            rzp1.open();

            return order;

        } catch (error) {
            console.error('Error creating order:', error);
            return null; 
        }
    };

    const validateOrder = async (orderData) => {
        try {
            const validateresponse = await axios.post('http://127.0.0.1:8000/api/validate/', orderData, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (validateresponse.status === 200) {
                const jsonresponse = validateresponse.data;
                sessionStorage.setItem('orderid', jsonresponse.orderId);
                return true;
            } else {
                console.error('Validation failed');
                return false;
            }
        } catch (error) {
            console.error('Error validating order:', error);
            return false;
        }
    };

    return (
        <>
          <Helmet>
                <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
            </Helmet>
            <div className={`modal fade ${isOpen ? 'show' : ''}`} style={{ display: 'block' }} tabIndex="-1" role="dialog">
            <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h3 className="booking-card-title">Customer Details</h3>
                            {hasid && <button
                                type="button"
                                className="btn-close"
                                aria-label="Close"
                                onClick={onClose}
                            ></button>}
                        </div>
                        <div className="modal-body">
                            <form className="booking-form" onSubmit={handleSubmit}>
                                <div className="form-group">
                                    <label htmlFor="name">Name</label>
                                    <input
                                        type="text"
                                        className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                                        id="customer_name"
                                        value={formData.customer_name}
                                        onChange={handleChange}
                                    />
                                    {errors.name && <div className="invalid-feedback">{errors.name}</div>}
                                </div>
                                <div className="form-group">
                                    <label htmlFor="contact">Contact</label>
                                    <input
                                        type="text"
                                        className={`form-control ${errors.contact ? 'is-invalid' : ''}`}
                                        id="contact_number"
                                        value={formData.contact_number}
                                        onChange={handleChange}
                                    />
                                    {errors.contact && <div className="invalid-feedback">{errors.contact}</div>}
                                </div>
                                <div className="form-group">
                                    <label htmlFor="address">Address</label>
                                    <input
                                        type="text"
                                        className={`form-control ${errors.address ? 'is-invalid' : ''}`}
                                        id="address"
                                        value={formData.address}
                                        onChange={handleChange}
                                    />
                                    {errors.address && <div className="invalid-feedback">{errors.address}</div>}
                                </div>
                            </form>
                        </div>
                        <div className="modal-footer">
                        <button type="submit" className="btn btn-success btn-lg m-auto" onClick={handleSubmit}>Pay Rs.51 to Access Services. </button>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div className="modal-backdrop fade show"></div>
        </>
    );
};

export default BootstrapModal;

import React from 'react';
import logo from '../assests/hth.jpg';
import './Footer.css'

const Footer = () => {
  return (
    <div className="footer">
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <h5>Address</h5>
            <p>HTH Hotel OPC Private Limited, C/O Vivek Tripathi, Infront of Petrol Pump, Ward No.12, Raghurajnagar, Badkhar, Satna(M.P.)-485005</p>
          </div>
          <div className="col-md-4">
            <h5>Office Helpline No.</h5>
            <p>+91-7027378204</p>
          </div>
          <div className="col-md-2 logo-container">
            <img src={logo} alt="Logo" />
          </div>
        </div>
      </div>
    </div>
  )
}
export default Footer
import { useEffect, useState } from 'react';
import axios from 'axios';
import './Home.css';
import Slider from './Slider';
import { useNavigate } from 'react-router-dom';
import BootstrapModal from './BootstrapModal';

const Home = ({ city }) => {
    const [data, setData] = useState([]);
    const [data1, setData1] = useState([]);
    const [selectedHotel, setSelectedHotel] = useState(null);
    const [showModal, setShowModal] = useState(true);
    const navigate = useNavigate();

    const handleBookNow = (hotel) => {
        setSelectedHotel(hotel);
        if (sessionStorage.getItem('orderid')) {
            navigate('/booking', { state: { hotel } });
        } else {
            navigate('/booking', { state: { hotel } });
        }
    };

    useEffect(() => {
        axios.get('http://127.0.0.1:8000/api/hotels/')
            .then((res) => {
                setData(res.data);
            })
            .catch((err) => console.error('Error fetching hotels:', err));
    }, []);

    useEffect(() => {
        if (data.length > 0) {
            const arr = data.filter((i) => i.city === city);
            setData1(arr);
            console.log(data1)
        }
    }, [city, data]);

    return (
        <>
            <Slider />
            <div className="container-hotel" id="navbartop">
                <h1 style={{ margin: '10px' }}>
                    The most Searched <span className='span-name'>Luxury</span> Hotels in {city}.
                </h1>
                <hr />
                <div className="flexbox">
                    {city && data1.map((i) => (
                        <div key={i.name}>
                            <div className="img_container">
                                <img src={`http://127.0.0.1:8000/${i.image}`} alt={i.name} />
                            </div>
                            <h3 className='p-2'>{i.name}</h3>
                            <p>{i.location}</p>
                            <p>&#8377;{i.price} per Day</p>
                            <button onClick={() => handleBookNow(i)}>Book Now</button>
                        </div>
                    ))}
                </div>
            </div>
            <div className="card text-center">
                <div className="card-header">Book Your Hotel</div>
                <div className="card-body">
                    <h5 className="card-title">within</h5>
                    <a id="#navbartop" className="btn btn-primary">5 minutes</a>
                    <p className="card-text">With 24x7 support.</p>
                </div>
            </div>

            {showModal && (
                <BootstrapModal
                    isOpen={showModal}
                    onClose={() => setShowModal(false)}
                />
            )}
        </>
    );
};

export default Home;

import React from 'react';
import { useNavigate } from 'react-router-dom';

const BookingSuccessful = () => {
    const navigate = useNavigate();

    const handleGoHome = () => {
        navigate('/'); 
    };

    return (
        <div className="container text-center mt-5 mb-5">
            <div className="card">
                <div className="card-body">
                    <h2 className="card-title text-success">Booking Successful!</h2>
                    <p className="card-text mt-3">
                        Your booking has been confirmed. We look forward to hosting you!
                    </p>
                    <p className="card-text">
                        Thank you for choosing our services.
                    </p>
                    <button
                        className="btn btn-primary btn-lg mt-4"
                        onClick={handleGoHome}
                    >
                        Go to Homepage
                    </button>
                </div>
            </div>
        </div>
    );
};

export default BookingSuccessful;

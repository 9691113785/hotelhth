import React, { useState } from 'react';
import './Booking.css'; 
import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';

function Booking() {
    const location = useLocation();
    const { hotel } = location.state;

    const [orderId, setOrderId] = useState("");
    const [formData, setFormData] = useState({
        customer_name: '',
        hotel: hotel.name,
        city: hotel.city,
        contact_number: '',
        check_in: '',
        number_of_day: '',
        gender: 'Male',
        payment_mode: 'Pay Online',
        number_of_rooms: 1,
        booking_amount: hotel.price
    });
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();
    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData({ ...formData, [id]: value });

        if (id === 'number_of_day') {
            const days = parseInt(value) || 0;
            const amount = days * hotel.price;
            setFormData(prevState => ({
                ...prevState,
                booking_amount: amount.toFixed(2)
            }));
        }
    };

    const validateForm = () => {
        const validationErrors = {};
        if (!formData.customer_name.trim()) {
            validationErrors.name = 'Name is required';
        }
        if (!formData.contact_number.trim()) {
            validationErrors.contact = 'Contact Number is required';
        } else if (!/^\d{10}$/.test(formData.contact_number.trim())) {
            validationErrors.contact = 'Contact Number must be 10 digits';
        }
        if (!formData.check_in) {
            validationErrors.checkInDate = 'CheckIn Date is required';
        } else {
            const today = new Date();
            const checkInDate = new Date(formData.check_in);
            if (checkInDate < today) {
                validationErrors.checkInDate = 'CheckIn Date must be today or later';
            }
        }
        if (!formData.number_of_day) {
            validationErrors.totaldaystostay = 'Number of Days to Stay is required';
        } else if (formData.number_of_day <= 0) {
            validationErrors.totaldaystostay = 'Days must be greater than 0';
        }

        return validationErrors;
    };

    const saveBooking = async () => {
        try {
            const response = await axios.post('http://127.0.0.1:8000/api/books/', formData);
            alert("Booking successfully.");
            navigate('/bookingsuccess')
        } catch (error) {
            console.error('Error saving booking:', error);
            alert("Failed to save booking.");
        }
    };

    const validateOrder = async (orderData) => {
        try {
            const validateresponse = await axios.post('http://127.0.0.1:8000/api/validate/', orderData, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (validateresponse.status === 200) {
                const jsonresponse = validateresponse.data;
                return true;
            } else {
                console.error('Validation failed');
                return false;
            }
        } catch (error) {
            console.error('Error validating order:', error);
            return false;
        }
    };



    const paymentHandler = async () => {
        const amount = formData.booking_amount * 100; 
        const currency = 'INR';
        const receiptId = "446545";
    
        try {
            const response = await axios.post('http://127.0.0.1:8000/api/create_order/', {
                amount: amount,
                currency: currency,
                receipt: receiptId
            }, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
    
            const order = response.data;
    
            return new Promise((resolve, reject) => {
                const options = {
                    key: "rzp_test_il5eIvVmXeSgBb", 
                    amount: amount,
                    currency: currency,
                    name: "HTH Hotel",
                    description: "Test Transaction",
                    image: "https://img.freepik.com/premium-vector/hotel-logo-simple-illustration_434503-736.jpg?w=2000",
                    order_id: order.id,
                    handler: async function (response) {
                        try {
                            const body = { ...response };
                            sessionStorage.setItem('orderid', body.razorpay_order_id);
    
                            const obj = { ...formData, razorpay_order_id: body.razorpay_order_id, razorpay_payment_id: body.razorpay_payment_id };
                            await axios.post('http://127.0.0.1:8000/api/books/', obj);
    
                            resolve(true); 
                        } catch (error) {
                            console.error('Error during order validation:', error);
                            reject(error); 
                        }
                    },
                    prefill: {
                        name: "HTH",
                        email: "a@gmail.com",
                        contact: "9691113785"
                    },
                    notes: {
                        address: "Razorpay Corporate Office"
                    },
                    theme: {
                        color: "#3309cc"
                    }
                };
    
                const rzp1 = new window.Razorpay(options);
                rzp1.on("payment.failed", function (response) {
                    alert("Payment Failed");
                    reject(new Error("Payment failed")); 
                });
                rzp1.open();
            });
    
        } catch (error) {
            console.error('Error creating order:', error);
            return null; 
        }
    };
    
    const handleSubmit = async (e) => {
        e.preventDefault();
        const validationErrors = validateForm();
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }
        
        try {
            const paymentSuccess = await paymentHandler(); 
            if (paymentSuccess) {
                saveBooking(); 
            }
        } catch (error) {
            console.error('Payment or booking failed:', error);
            alert('There was an issue with the payment. Please try again.');
        }
    };
   
    return (
        <div className="booking-container">
            <div className="booking-card">
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img3.webp" alt="Sample photo" className="booking-card-image" />
                <div className="booking-card-body">
                    <h3 className="booking-card-title">Customer Details</h3>
                    <form className="booking-form" onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label htmlFor="customer_name">Name</label>
                            <input
                                type="text"
                                className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                                id="customer_name"
                                value={formData.customer_name}
                                onChange={handleChange}
                            />
                            {errors.name && <div className="invalid-feedback">{errors.name}</div>}
                        </div>
                        <div className="form-group">
                            <label htmlFor="contact_number">Contact Number</label>
                            <input
                                type="text"
                                className={`form-control ${errors.contact ? 'is-invalid' : ''}`}
                                id="contact_number"
                                value={formData.contact_number}
                                onChange={handleChange}
                            />
                            {errors.contact && <div className="invalid-feedback">{errors.contact}</div>}
                        </div>
                        <div className="form-group">
                            <label htmlFor="hotel">Hotel Name</label>
                            <input
                                type="text"
                                className="form-control"
                                id="hotel"
                                value={`${formData.hotel}, ${formData.city}`}
                                readOnly
                            />
                        </div>
                        <div className="form-row">
                            <div className="form-group col-md-6">
                                <label htmlFor="check_in">CheckIn Date</label>
                                <input
                                    type="date"
                                    className={`form-control datepicker ${errors.checkInDate ? 'is-invalid' : ''}`}
                                    id="check_in"
                                    value={formData.check_in}
                                    onChange={handleChange}
                                />
                                {errors.checkInDate && <div className="invalid-feedback">{errors.checkInDate}</div>}
                            </div>
                            <div className="form-group col-md-6">
                                <label htmlFor="number_of_day">Total Days to Stay</label>
                                <input
                                    type="number"
                                    className={`form-control ${errors.totaldaystostay ? 'is-invalid' : ''}`}
                                    id="number_of_day"
                                    value={formData.number_of_day}
                                    onChange={handleChange}
                                />
                                {errors.totaldaystostay && <div className="invalid-feedback">{errors.totaldaystostay}</div>}
                            </div>
                            <div className="form-group col-md-6">
                                <label htmlFor="gender">Gender</label>
                                <select
                                    className="form-control"
                                    id="gender"
                                    value={formData.gender}
                                    onChange={handleChange}
                                >
                                    <option>Male</option>
                                    <option>Female</option>
                                </select>
                            </div>
                        </div>
                        <div className="form-group">
                            <label htmlFor="booking_amount">Amount To Pay</label>
                            <input
                                type="text"
                                className="form-control"
                                id="booking_amount"
                                value={formData.booking_amount}
                                readOnly
                            />
                        </div>

                        <button type="submit" className="btn btn-success btn-lg">Pay and Book</button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default Booking;

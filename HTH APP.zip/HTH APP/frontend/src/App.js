import React, { useEffect, useState } from 'react';
import './App.css';
import Header from './Components/Header';
import Home from './Components/Home';
import Footer from './Components/Footer';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import NotFound from './Components/NotFound';
import Booking from './Components/Booking';
import About from './Components/About';
import Contact from './Components/Contact';
import axios from 'axios';
import BootstrapModal from './Components/BootstrapModal';
import BookingSuccessful from './Components/BookingSuccessful';

function App() {
  const [data, setData] = useState([]);
  const [city, setCity] = useState([]);
  const [dropdownValue, setDropdownValue] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(!!sessionStorage.getItem('orderid'));
 
  const handleDropdownChange = (e) => {
    const values = e.target.value;
    setDropdownValue(values);
  };

  const handleSearch = () => {
    alert(`Selected: ${dropdownValue}`);
  };

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/api/hotels/')
        .then((res) => {
            setData(res.data);
            const uniqueCities = [...new Set(res.data.map(item => item.city))];          
            setCity(uniqueCities);
        })
        .catch((err) => console.log(err));
}, []);

  return (
    <div>
      <BrowserRouter>
        <Header city={city} onDropdownChange={handleDropdownChange} />

        <Routes>
          <Route path="/" element={<Home city={dropdownValue} />} />
          <Route path="/home" element={<Home city={dropdownValue} />} />
          <Route path="/booking" element={<Booking />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/bookingsuccess" element={<BookingSuccessful />} />
          <Route path="*" element={<NotFound />} /> {/* Catch-all for 404 */}
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;

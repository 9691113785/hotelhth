import React, { useEffect, useState } from 'react';
import './App.css';
import Header from './Components/Header';
import Home from './Components/Home';
import Footer from './Components/Footer';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import NotFound from './Components/NotFound';
import Booking from './Components/Booking';
import About from './Components/About';
import Contact from './Components/Contact';
import axios from 'axios';

function App() {
  const [data, setData] = useState([]);

  const [city, setCity] = useState([]);
  const [dropdownValue, setDropdownValue] = useState('');
  
  const [isLoggedIn, setIsLoggedIn] = useState(!!sessionStorage.getItem('orderid'));
  console.log(isLoggedIn)

  const handleDropdownChange = (e) => {
    setDropdownValue(e.target.value);
  };

  const handleSearch = () => {
    alert(`Selected: ${dropdownValue}`);
    // You can perform further actions based on the selected city
  };
  useEffect(()=>{
    axios.get('http://127.0.0.1:8000/api/hotels/').then((res)=>{
      setData(res);
      const filteredCities = res.map(item => item.city);
    setCity(filteredCities);
    }).catch((err)=>console.log(err))
  },[])

  return (
    <div>
      <BrowserRouter>
      <Header city={city} onDropdownChange={handleDropdownChange} onSearch={handleSearch} />
      <Routes>
      
          <Route path="/" element={<Home city={dropdownValue} />} />
          <Route path="/home" element={<Home city={dropdownValue} />} />
          <Route path="/booking" element={<Booking />} />


          {/* <Route path="/booking" element={isLoggedIn ? <Booking /> : <Home path="/" city={dropdownValue}/>} /> */}
          
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />


          <Route path="*" element={<NotFound />} /> {/* Catch-all for 404 */}
        </Routes>
      <Footer />

      
      </BrowserRouter>
    </div>
  );
}

export default App;

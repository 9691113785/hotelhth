import { useEffect, useState, useRef } from 'react';
import axios from 'axios'
import { Helmet } from 'react-helmet';
import './Home.css';
import Slider from './Slider'
import { useNavigate } from 'react-router-dom';


const Home = ({ city }) => {
    const [data, setData] = useState([]);
    const [data1, setData1] = useState([]);
    const [selectedHotel, setSelectedHotel] = useState(null);
    const [toggle,settoggle]=useState(true);
    const[hasid,sethasId] = useState(sessionStorage.getItem('orderid')!=null);

    const [formData, setFormData] = useState({
        name: '',
        contact: '',
        address:''
    });

    const [errors, setErrors] = useState({});

    const handleChange = (e) => {
        const { id, value, type, files } = e.target;
    
        if (type === 'file') {
            setFormData({ ...formData, [id]: files[0] });
        } else {
            setFormData({ ...formData, [id]: value });
            }
        }
    



    const handleSubmit = async (e) => {
        e.preventDefault();
        
        const validationErrors = {};
        if (!formData.name.trim()) {
            validationErrors.name = 'Name is required';
        }
        if (!formData.contact.trim()) {
            validationErrors.contact = 'Contact Number is required';
        } else if (!/^\d{10}$/.test(formData.contact.trim())) {
            validationErrors.contact = 'Contact Number must be 10 digits';
        }
        
        if (!formData.address) {
            validationErrors.address = 'Address is required';
        }
        
        

       
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }
console.log("SD")
        axios.post('http://127.0.0.1:8000/api/customer_find/',formData)

        if (!hasPaymentHandlerRun.current) {
            paymenthandler();
            hasPaymentHandlerRun.current = true;
        }
       
    };


    const navigate = useNavigate();
    const hasPaymentHandlerRun = useRef(false);

    const handleBookNow = (hotel) => {
        console.log("BTNCLICK")
        setSelectedHotel(hotel);
        if (sessionStorage.getItem('orderid')) {
            console.log(sessionStorage.getItem('orderid'), "ORR")
            navigate('/booking', { state: { hotel } });
        } else {
            console.log(sessionStorage.getItem('orderid'), "not")
            navigate('/booking', { state: { hotel } });
            // navigate('/');
            // window.location.reload();
            console.log("homee");
        }
    };

    const paymenthandler = async () => {
        const amount = 21 * 100;
        const currency = 'INR';
        const receiptId = "446545";

        try {
            const response = await axios.post('http://127.0.0.1:8000/api/create_order/', {
                amount: amount,
                currency: currency,
                receipt: receiptId
            }, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const order = response.data;
            console.log('Received order from server:', order);

            const options = {
                key: "rzp_test_il5eIvVmXeSgBb",
                amount: amount,
                currency: currency,
                name: "HTH Hotel",
                description: "Test Transaction",
                image: "https://img.freepik.com/premium-vector/hotel-logo-simple-illustration_434503-736.jpg?w=2000",
                order_id: order.id,
                handler: async function (response) {
                    try {
                        const body = { ...response };
                        const validateresponse = await fetch('http://127.0.0.1:8000/api/validate/', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify(body)
                        });
                        
                        if (!validateresponse.ok) {
                            throw new Error('Validation failed');
                        }
            
                        const jsonresponse = await validateresponse.json();
                        sessionStorage.setItem('orderid', jsonresponse.orderId);
                        sethasId(true);
                        console.log('Order validated and stored in session:', jsonresponse);
                    } catch (error) {
                        console.error('Error validating order:', error);
                    }
                },
                prefill: {
                    name: "HTH",
                    email: "a@gmail.com",
                    contact: "9691113785"
                },
                notes: {
                    address: "Razorpay Corporate Office"
                },
                theme: {
                    color: "#3309cc"
                }
            };
            

            const rzp1 = new window.Razorpay(options);
            rzp1.on("payment.failed", function (response) {
                alert("Payment Failed");
                console.log(response.error.code);
            });
            rzp1.open();
        } catch (error) {
            console.error('Error creating order:', error);
        }
    };

    useEffect(() => {

        axios.get('http://127.0.0.1:8000/api/hotels/').then((res)=>{
            console.log("hotel", res)
            setData(res);
        })
    }, []);

    useEffect(() => {
        setData1(data.filter((i) => i.city === city));
    }, [city]);

    return (
        <>
            <Slider />
            <Helmet>
                <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
            </Helmet>

            


            <div className="booking-container">
    <div className="booking-card">
        <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img3.webp" alt="Sample photo" className="booking-card-image" />
        <div className="booking-card-body">
            <h3 className="booking-card-title">Customer Details</h3>
            <form className="booking-form" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="name">Name</label>
                    <input
                        type="text"
                        className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                        id="name"
                        value={formData.name}
                        onChange={handleChange}
                    />
                    {errors.name && <div className="invalid-feedback">{errors.name}</div>}
                </div>
                <div className="form-group">
                    <label htmlFor="contact">Contact</label>
                    <input
                        type="text"
                        className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                        id="contact"
                        value={formData.contact}
                        onChange={handleChange}
                    />
                    {errors.contact && <div className="invalid-feedback">{errors.contact}</div>}
                </div>
                <div className="form-group">
                    <label htmlFor="address">Address</label>
                    <input
                        type="text"
                        className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                        id="address"
                        value={formData.address}
                        onChange={handleChange}
                    />
                    {errors.address && <div className="invalid-feedback">{errors.address}</div>}
                </div>

                <button type="submit" className="btn btn-success btn-lg">Submit</button>
            </form>
        </div>
    </div>
</div>





            <div className="container-hotel" id="navbartop">
                <h1 style={{ margin: '10px' }}>The most Searched <span className='span-name'>Luxury</span> Hotels in {city}.</h1>
                <hr />
                <div className="flexbox">
                    {city && data1.map((i) =>
                        <div key={i.name}>
                            <div className="img_container"><img src={i.img} alt={i.name} /></div>
                            <h3 className='p-2'>{i.name}</h3>
                            <p>{i.location}</p>
                            <p>&#8377;{i.price} per Day</p>
                            <button onClick={() => handleBookNow(i)}>Book Now</button>
                        </div>
                    )}
                </div>
            </div>
            <div className="card text-center">
                <div className="card-header">Book Your Hotel</div>
                <div className="card-body">
                    <h5 className="card-title">within</h5>
                    <a id="#navbartop" className="btn btn-primary">5 minutes</a>
                    <p className="card-text">With 24x7 support.</p>
                </div>
            </div>
        </>
    );
};

export default Home;

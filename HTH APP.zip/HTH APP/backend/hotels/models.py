from django.db import models

class Hotel(models.Model):
    image = models.ImageField(upload_to='booking_images/', null=True, blank=True)
    name = models.CharField(max_length=100)
    city = models.CharField(max_length=50)
    location = models.TextField()
    facility = models.CharField(max_length=50)
    price  = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name

class Booking(models.Model):
    customer_name = models.CharField(max_length=100)
    hotel = models.CharField(max_length=100)
    check_in = models.DateField()
    number_of_day = models.IntegerField()
    gender = models.CharField(max_length=10)
    booking_amount = models.DecimalField(max_digits=10, decimal_places=2)
    number_of_rooms = models.PositiveIntegerField()
    contact_number = models.CharField(max_length=15)
    payment_mode = models.CharField(max_length=20)
    razorpay_order_id = models.CharField(max_length=255, blank=True, null=True)
    razorpay_payment_id = models.CharField(max_length=255, blank=True, null=True)

class CustomerFind(models.Model):
    customer_name = models.CharField(max_length=100)
    contact_number = models.CharField(max_length=15)
    address = models.TextField()
    razorpay_order_id = models.CharField(max_length=255, blank=True, null=True)
    razorpay_payment_id = models.CharField(max_length=255, blank=True, null=True)
    

    

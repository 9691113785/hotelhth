from django.urls import path
from .views import *


urlpatterns = [
    path('hotels/', HotelListView.as_view(), name='hotel-list'),
    path('hotels/<int:pk>/', HotelDetailView.as_view(), name='hotel-detail'),
    path('books/', BookingCreateView.as_view(), name='booking'),
    path('customers/', CustomerFindView.as_view(), name='customer-find'),
    path('', home),
    path('create_order/', create_order),
]
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Hotel
from .serializers import HotelSerializer , BookingSerializer
from django.db.models import Q
from django.shortcuts import get_object_or_404
from rest_framework import viewsets
from .models import CustomerFind
from .serializers import CustomerFindSerializer
from django.http import JsonResponse
from rest_framework.decorators import api_view
import razorpay
from .views import *


class HotelListView(APIView):
    def get(self, request):
        name = request.GET.get('name', None)
        city = request.GET.get('city', None)
        min_rating = request.GET.get('min_rating', None)
        max_price = request.GET.get('max_price', None)

        filters = Q()
        if name:
            filters &= Q(name__icontains=name)
        if city:
            filters &= Q(city__icontains=city)
        if min_rating:
            filters &= Q(rating__gte=min_rating)
        if max_price:
            filters &= Q(price_per_night__lte=max_price)

        hotels = Hotel.objects.filter(filters)
        serializer = HotelSerializer(hotels, many=True)

        return Response(serializer.data, status=status.HTTP_200_OK)
    
class HotelDetailView(APIView):
    def get(self, request, pk):
        hotel = get_object_or_404(Hotel, pk=pk)
        serializer = HotelSerializer(hotel)
        return Response(serializer.data, status=status.HTTP_200_OK)

class BookingCreateView(APIView):
    def post(self, request):
        serializer = BookingSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class CustomerFindView(APIView):
    def get(self, request, *args, **kwargs):
        queryset = CustomerFind.objects.all()
        serializer = CustomerFindSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        serializer = CustomerFindSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def home(request):
    return JsonResponse({"message": "Hello World!"})

@api_view(['POST'])
def create_order(request):
    key_id = 'rzp_test_il5eIvVmXeSgBb'
    key_secret = 'xY2xLqz7UqF6USU3j62oS6jj'
    amount = request.data.get('amount')
    
    client = razorpay.Client(auth=(key_id, key_secret))
    
    data = {
        "amount": amount,
        "currency": "INR",
        "payment_capture": 1
    }
    
    order = client.order.create(data=data)
    return JsonResponse(order)
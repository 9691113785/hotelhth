from django.contrib import admin
from .models import Hotel, Booking , CustomerFind

@admin.register(Hotel)
class HotelAdmin(admin.ModelAdmin):
    list_display = ('name', 'city', 'facility', 'price')
    list_filter = ('city', 'facility')
    search_fields = ('name', 'city', 'facility')
    ordering = ('name',)

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('customer_name', 'hotel', 'check_in', 'number_of_day', 'gender', 'booking_amount', 'number_of_rooms', 'contact_number', 'payment_mode')
    list_filter = ('hotel', 'check_in', 'gender', 'payment_mode')
    search_fields = ('customer_name', 'hotel__name', 'contact_number')
    ordering = ('-check_in',)

class CustomerFindAdmin(admin.ModelAdmin):
    list_display = ('customer_name', 'contact_number', 'address')
    search_fields = ('customer_name', 'contact_number')

admin.site.register(CustomerFind, CustomerFindAdmin)





const express = require('express');
const cors = require('cors');
const crypto = require('crypto')
const bodyParser = require('body-parser');
const Razorpay = require('razorpay');

const app = express();
const port = 5000;


const razorpay = new Razorpay({
    key_id: 'rzp_test_il5eIvVmXeSgBb',
    key_secret: 'xY2xLqz7UqF6USU3j62oS6jj'
});


app.use(bodyParser.json());
app.use(cors())
app.use(express.json());

app.use(express.urlencoded({extended:false}));

app.get('/',(req,res)=>{
    res.send("server is running")
})


app.post('/create-order', async (req, res) => {
    try {
        const options = req.body;
        const order = await razorpay.orders.create(options);
        res.json(order);

       
    } catch (error) {
       
        console.error('Error creating order:', error);
        res.status(500).json({ error: 'Failed to create Razorpay order' });
    }
});

app.post('/validate', async (req, res) => {
    const { order_id, payment_id, signature } = req.body;
  
    const crypto = require('crypto');
  
    const generated_signature = crypto
      .createHmac('sha256', razorpay.key_secret)
      .update(order_id + "|" + payment_id)
      .digest('hex');
  
    if (generated_signature === signature) {
      res.status(200).send({ status: 'success', message: 'Payment is valid' });
    } else {
      res.status(400).send({ status: 'failure', message: 'Invalid payment' });
    }
  });




app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
